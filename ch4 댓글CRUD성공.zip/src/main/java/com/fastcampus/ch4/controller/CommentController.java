package com.fastcampus.ch4.controller;

import com.fastcampus.ch4.domain.CommentDto;
import com.fastcampus.ch4.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
public class CommentController {
    @Autowired
    CommentService service;

    // 댓글목록 보여주는 메서드
    @GetMapping("/comments") // comments?bno=1080
    @ResponseBody public ResponseEntity<List<CommentDto>> list(Integer bno) {
        List<CommentDto> list = null;
        try {
            list = service.getList(bno);
            //System.out.println("list = " + list);
            return new ResponseEntity<List<CommentDto>>(list, HttpStatus.OK); // 200번 응답(성공)
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<List<CommentDto>> (HttpStatus.BAD_REQUEST); // 400번 응답(실패)
        }
    }

    // 댓글 삭제하는 메서드
    @DeleteMapping("/comments/{cno}")  // /comments/1?bno=1085 <-- 삭제할 댓글 번호
    @ResponseBody
    public ResponseEntity<String> remove(@PathVariable Integer cno, int bno, HttpSession session){  // 다른것과 달리 삭제시는 @PathVariable 사용한다고한다..
        // String commenter = (String)session.getAttribute("id"); 로그인을 안하고 테스트 중이기에 일단 주석
        String commenter = "choco5732";
        try {
            int rowCnt = service.remove(cno, bno, commenter);

            if(rowCnt!=1)  // rowCnt가 1이어야 잘 삭제되엇단 뜻 근데 1이 아니면 에러발생
                throw new Exception("Delete Failed");
            // 반면 잘 삭제된 경우 DEL_OK
            return new ResponseEntity<>("DEL_OK", HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>("DEL_ERR", HttpStatus.BAD_REQUEST);
        }
    }


    // 댓글을 등록하는 메서드
    @ResponseBody
    @PostMapping("/comments")   // /comments?bno=1085
    public ResponseEntity<String> write(@RequestBody CommentDto dto, Integer bno, HttpSession session){
        // 로그인을 안한 채로 테스트중이기에 하드코딩으로 직접 commenter 넣어줬음, 원래는 세션에서 아이디값을 받아오는 방식으로 해야됨
        String commenter = "choco5732";
        dto.setCommenter(commenter);
        dto.setBno(bno);
        System.out.println("dto = " + dto);

        try {
            if(service.write(dto)!=1)
                throw new Exception("Write failed.");
            return new ResponseEntity<>("WRT_OK", HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<String>("WRT_ERR", HttpStatus.BAD_REQUEST);
        }
    }

    // 댓글을 수정하는 메서드
    @ResponseBody
    @PatchMapping("/comments/{cno}")   // /comments/70  PATCH
    public ResponseEntity<String> modify(@PathVariable Integer cno, @RequestBody CommentDto dto, HttpSession session){
        // String commenter = (String)sesson.getAttribute("id");
        String commenter = "choco5732";
        dto.setCommenter(commenter);
        dto.setCno(cno);
        System.out.println("dto = " + dto);

        try {
            if(service.modify(dto)!=1)
                throw new Exception("Write failed.");

            return new ResponseEntity<>("MOD_OK", HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<String>("MOD_ERR", HttpStatus.BAD_REQUEST);
        }
    }

}

