package kr.co.fusionsoft.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.co.fusionsoft.domain.BoardDto;
import kr.co.fusionsoft.domain.PageHandler;
import kr.co.fusionsoft.domain.SearchCondition;
import kr.co.fusionsoft.service.BoardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

@Controller
@RequestMapping("/board")
public class BoardController {
    @Autowired
    BoardService boardService;

    @GetMapping("/write")
    public String write(Model m) {
        m.addAttribute("mode","new");
        return "board"; // board.jsp를 mode=new면 쓰기, new가 아니면 읽기모드로.
    }

    @PostMapping("/modify")
    public String modify(BoardDto boardDto, Model m, HttpSession session, RedirectAttributes rattr) {
        String writer = (String)session.getAttribute("id");
        boardDto.setWriter(writer);

        try {
            int rowCnt = boardService.modify(boardDto);
            if(rowCnt!=1) // 글쓰기 실패하면
                throw new Exception("modify failed."); // 게시판으로 가지 않고 입력했던 내용으로 다시 board창
            rattr.addFlashAttribute("msg", "Modify_OK");

            return "redirect:/board/list";
        } catch (Exception e) {
            e.printStackTrace();
            m.addAttribute("boardDto", boardDto);
            m.addAttribute("msg","Modify_Error");
            return "board";
        }

    }


    @PostMapping("/write")
    public String write(BoardDto boardDto, Model m, HttpSession session, RedirectAttributes rattr) {
        String writer = (String)session.getAttribute("id");
        boardDto.setWriter(writer);

        try {
            int rowCnt = boardService.write(boardDto);
            if(rowCnt!=1) // 글쓰기 실패하면
                throw new Exception("Write failed."); // 게시판으로 가지 않고 입력했던 내용으로 다시 board창
            rattr.addFlashAttribute("msg", "Write_OK");

            return "redirect:/board/list";
        } catch (Exception e) {
            e.printStackTrace();
            m.addAttribute("boardDto", boardDto);
            m.addAttribute("msg","Write_Error");
            return "board";
        }

    }

    @PostMapping("/remove")
    public String remove(Integer bno, Integer page, Integer pageSize, Model m, HttpSession session, RedirectAttributes rattr) {
        String writer = (String)session.getAttribute("id");
        try {
            m.addAttribute("page", page);
            m.addAttribute("pageSize", pageSize);

            int rowCnt = boardService.remove(bno, writer);

            if(rowCnt!=1)
                throw new Exception("board remove error occured!");
            rattr.addFlashAttribute("msg", "Delete_OK");  // addFlashAttribute는 한번만 쓰고 없어짐 ,, 일회성,, 세션에 저장했다가 한번 쓰고 삭제 (세션 이용)
        } catch (Exception e) {
            e.printStackTrace();
            rattr.addFlashAttribute("msg", "Delete_Error");
        }
        // 위와 같이 모델에 담아주면
        // 아래 리다이렉트 문에 이어서 달림 /board/list?page=...
        return "redirect:/board/list";
    }


    @GetMapping("/read")
    public String read(Integer bno, Integer page, Integer pageSize, Model m, HttpServletRequest request, HttpServletResponse response, HttpSession session )throws Exception{
//        try {
            BoardDto boardDto = boardService.read(bno);

        Cookie[] cookies = request.getCookies();
        Cookie testCookie = null;

        if( cookies != null && cookies.length >0)
        {
            for (int i = 0; i < cookies.length; i++)
            {
                if(cookies[i].getName().equals("cookie" +bno))
                {
                    System.out.println("처음 쿠키가 생성된 뒤 들어옴.");
                    testCookie = cookies[i];
                }
            }
        }

        if(testCookie == null){
            System.out.println("쿠키없음");

            Cookie newCookie = new Cookie("cookie"+bno, "|"+bno+"|");
            newCookie.setMaxAge(60*60*24);  // 쿠키 유호기간을 하루로 설정, 하루가 지나면 조회수 증가
            response.addCookie(newCookie);
            boardService.viewCnt(bno);

        }
            // m.addAttribute("boardDto", boardDto); 와 동일 문장
            m.addAttribute(boardDto);
            m.addAttribute("page", page);
            m.addAttribute("pageSize", pageSize);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
        return "board";
    }

    @GetMapping("/list")
    public String list(SearchCondition sc, Model m,  HttpServletRequest request) {
        if(!loginCheck(request))
            return "redirect:/login/login?toURL="+request.getRequestURL();
        // 로그인을 안했으면 로그인 화면으로 이동

//        // 만약 값이 없다면 page=1, pagesize=10으로 주는 설정
//        if(page==null) page=1;
//        if(pageSize==null) pageSize=10;
//

        try {
            int totalCnt = boardService.getSearchResultCnt(sc);
            m.addAttribute("totalCnt", totalCnt);

            PageHandler pageHandler = new PageHandler(totalCnt, sc);

            List<BoardDto> list = boardService.getSearchResultPage(sc);
            m.addAttribute("list", list);
            m.addAttribute("ph", pageHandler);

            Instant startOfToday = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant();
            m.addAttribute("startOfToday", startOfToday.toEpochMilli());
        } catch (Exception e) {
            e.printStackTrace();
            m.addAttribute("msg", "LIST_ERR");
            m.addAttribute("totalCnt", 0);
        }

        return "boardList";
    }

    private boolean loginCheck(HttpServletRequest request) {
        // 1. 세션 객체를 얻어서
        HttpSession session = request.getSession();
        // 2. 세션에 id가 있는지 확인, 있으면 true를 반환
        return session.getAttribute("id")!=null;
    }
}

