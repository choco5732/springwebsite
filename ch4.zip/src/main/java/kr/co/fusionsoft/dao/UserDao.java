package kr.co.fusionsoft.dao;

import kr.co.fusionsoft.domain.*;
import kr.co.fusionsoft.domain.User;

public interface UserDao {
    User selectUser(String id);
    int deleteUser(String id);
    int insertUser(User user);
    int updateUser(User user);
    void deleteAll() throws Exception;
}