package com.fastcampus.ch2;

public class Car    { 
	private String color = "red"; 
	public String getColor() { return color; }
}