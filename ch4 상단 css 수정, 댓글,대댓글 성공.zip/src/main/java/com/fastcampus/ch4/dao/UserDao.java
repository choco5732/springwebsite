package com.fastcampus.ch4.dao;

import com.fastcampus.ch4.domain.*;

public interface UserDao {
    User selectUser(String id);
    int deleteUser(String id);
    int insertUser(User user);
    int updateUser(User user);
    void deleteAll() throws Exception;
}